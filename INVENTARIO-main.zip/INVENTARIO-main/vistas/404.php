<div class="main-container">
	<section class="hero-body">
	  	<div class="hero-body">
		    <p class="title">
		      Error 404
		    </p>
		    <p class="subtitle">
		      Pagina no encontrada
		    </p>
	  	</div>
	</section>
</div>