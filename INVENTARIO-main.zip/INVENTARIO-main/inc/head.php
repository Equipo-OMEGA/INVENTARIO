<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Inventario web</title>
<link rel="stylesheet" href="./css/bulma.min.css">
<link rel="stylesheet" href="./css/estilos.css">
<link rel="icon" href="./img/icono_invent.ico">